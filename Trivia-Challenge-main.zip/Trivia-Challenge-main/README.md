# Trivia-Challenge
Trivia Challenge game with many trivia questions and a score
